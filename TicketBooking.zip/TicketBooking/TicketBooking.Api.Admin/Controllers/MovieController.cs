﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TicketBooking.Api.Admin.Models;
using System.Text;
using System.Data.SqlClient;
using System.Collections.ObjectModel;
using System.Net;
using System.Net.Http;

namespace TicketBooking.Api.Admin.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieController : ControllerBase
    {

        [HttpPost("AddMovie")]
        public ActionResult AddMovie([FromBody] Movie movie)
        {
            try
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
                builder.DataSource = "azuresrv.database.windows.net";
                builder.UserID = "user";
                builder.Password = "Password123";
                builder.InitialCatalog = "ticketbooking";

                using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
                {
                    connection.Open();
                    StringBuilder sb = new StringBuilder();
                    sb.Append("INSERT INTO MOVIE (MovieName, MultiplexName, AvaliableTickets, MovieDate) ");
                    sb.Append("VALUES ");
                    sb.Append("(" + "'" + movie.MovieName + "'");
                    sb.Append("," + "'" + movie.MultiplexName + "'");
                    sb.Append("," + movie.AvaliableTickets + "");
                    sb.Append("," + "'" + movie.MovieDate.ToLongDateString() + "')");
                    String sql = sb.ToString();

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }
                return StatusCode(200, "Movie Added Successfully");
            }
            catch (SqlException e)
            {
                return StatusCode(417, e.Message);
            }

        }

        
    }
}
