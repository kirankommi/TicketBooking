﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TicketBooking.Api.BookShow.Models;
using System.Data.SqlClient;
using System.Text;
using System.Collections.ObjectModel;
using System.Net;
using System.Net.Http;

namespace TicketBooking.Api.BookShow.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookShowController : ControllerBase
    {
        [HttpPost("BookTicket")]
        public ActionResult<IList<tblMovie>> BookTicket([FromBody] SearchModel search)
        {
            try
            {
                if(search.Tickets > 5)
                {
                    return StatusCode(404,"Please select Less than 6 Tickets");
                }

                int TicketsAvailability = 0;
                int ID = 0;

                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
                builder.DataSource = "azuresrv.database.windows.net";
                builder.UserID = "user";
                builder.Password = "Password123";
                builder.InitialCatalog = "ticketbooking";

                using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
                {
                    connection.Open();
                    StringBuilder sb = new StringBuilder();

                    //search to check whether movie is available with the given search parameters
                    sb.Append("SELECT ID, MovieName, MultiplexName, AvaliableTickets, MovieDate ");
                    sb.Append("FROM Movie ");
                    sb.Append("WHERE MovieName =  " + "'" +  search.MovieName + "'");
                    sb.Append(" AND MultiplexName =  " + "'" + search.MultiplexName + "'");
                    sb.Append(" AND AvaliableTickets >=  " + "" + search.Tickets + "");
                    sb.Append(" AND MovieDate =  " + "'" + search.MovieDate.ToShortDateString() + "'");
                    String sql = sb.ToString();

                    //connection.Open();
                    SqlCommand command = new SqlCommand(sql, connection);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while(reader.Read())
                        {
                            TicketsAvailability = (int)reader["AvaliableTickets"] - search.Tickets;
                            ID = (int)reader["ID"];
                            reader.Close();

                            //insert ticket details into ticet table
                            StringBuilder sb2 = new StringBuilder();
                            sb2.Append("INSERT INTO TICKET(MovieName, MultiplexName, Tickets, MovieDate) ");
                            sb2.Append("VALUES ");
                            sb2.Append("('" + search.MovieName + "'");
                            sb2.Append(",'" + search.MultiplexName + "'");
                            sb2.Append("," + search.Tickets + "");
                            sb2.Append(",'" + search.MovieDate.ToShortDateString() + "')");
                            String sql2 = sb2.ToString();

                            SqlCommand command2 = new SqlCommand(sql2, connection);
                            command2.ExecuteNonQuery();

                            //update no.of tickets available for that movie
                            StringBuilder sb3 = new StringBuilder();
                            sb3.Append("UPDATE MOVIE SET avaliabletickets = ");
                            sb3.Append("" + TicketsAvailability + "");
                            sb3.Append(" WHERE ID = ");
                            sb3.Append("" + ID + "");
                            String sql3 = sb3.ToString();
                            SqlCommand command3 = new SqlCommand(sql3, connection);
                            command3.ExecuteNonQuery();

                            break;
                        }
                    }
                }
                return StatusCode(200,"Ticket Booked Successfully");
            }
            catch (SqlException e)
            {
                return StatusCode(417, e.Message);
            }
        }
    }
}
