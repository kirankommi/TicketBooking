﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TicketBooking.Api.BookShow.Models
{
    public class tblMovie
    {
        public int ID { get; set; }
        public string MovieName { get; set; }
        public string MultiplexName { get; set; }
        public int AvaliableTickets { get; set; }
        public DateTime MovieDate { get; set; }
    }
}
