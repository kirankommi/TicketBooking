﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Data.SqlClient;
using TicketBooking.Api.Users.Models;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Collections.ObjectModel;
using System.Collections;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;

namespace TicketBooking.Api.Users.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        [HttpPost("AddUser")]
        public ActionResult AddUser([FromBody] User user)
        {
            try
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
                builder.DataSource = "azuresrv.database.windows.net";
                builder.UserID = "user";
                builder.Password = "Password123";
                builder.InitialCatalog = "users";

                using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
                {
                    connection.Open();
                    StringBuilder sb = new StringBuilder();
                    //Adding user into Database
                    sb.Append("INSERT INTO USERS (UserName, Password, Role) ");
                    sb.Append("VALUES ");
                    sb.Append("(" + "'" + user.UserName + "'");
                    sb.Append("," + "'" + user.Password + "'");
                    sb.Append("," + user.Role + ")");
                    String sql = sb.ToString();

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }
                return StatusCode(200,"User added successfully");
            }
            catch (SqlException e)
            {
                return StatusCode(417, e.Message);
            }
        }

        [HttpGet("LoginUser")]
        public string LoginUser(string UserID, string Password)
        {
            //Get user details for the user who is trying to login
            var user = UserList.SingleOrDefault(x => x.UserID == UserID);

            //Authenticate User, Check if it’s a registered user in Database
            if (user == null)
                return null;

            //If it's registered user, check user password stored in Database 
            //For demo, password is not hashed. Simple string comparison 
            //In real, password would be hashed and stored in DB. Before comparing, hash the password
            if (Password == user.Password)
            {
                //Authentication successful, Issue Token with user credentials
                //Provide the security key which was given in the JWToken configuration in Startup.cs
                var key = Encoding.ASCII.GetBytes
                          ("YourKey-2374-OFFKDI940NG7:56753253-tyuw-5769-0921-kfirox29zoxv");
                //Generate Token for user 
                var JWToken = new JwtSecurityToken(
                    issuer: "http://localhost:50082/",
                    audience: "http://localhost:50082/",
                    claims: null,
                    notBefore: new DateTimeOffset(DateTime.Now).DateTime,
                    expires: new DateTimeOffset(DateTime.Now.AddDays(1)).DateTime,
                    //Using HS256 Algorithm to encrypt Token
                    signingCredentials: new SigningCredentials(new SymmetricSecurityKey(key),
                                        SecurityAlgorithms.HmacSha256Signature)
                );
                var token = new JwtSecurityTokenHandler().WriteToken(JWToken);
                return token;
            }
            else
            {
                return null;
            }
        }

        private List<User> UserList = new List<User>
        {
            new User { UserID = "kiran",
            Password = "kiran", Role = "Admin"}
        };

        //Using hard coded collection list as Data Store for demo. 
        //In reality, User data comes from Database or other Data Source 
        private IEnumerable GetUserClaims(User user)
        {
            IEnumerable claims = new Claim[]
                    {
                        new Claim(ClaimTypes.Name , user.UserName),
                        new Claim("ACCESS_LEVEL", user.Role.ToString())
                    };
            return claims;
        }

    }

    
}
