﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AdminUnitTest.Models
{
    public class Movie
    {
        public string MovieName { get; set; }
        public string MultiplexName { get; set; }
        public int AvaliableTickets { get; set; }
        public DateTime MovieDate { get; set; }
        public string City { get; set; }
        public string Genre { get; set; }
        public string Language { get; set; }
    }
}
