using System;
using Xunit;
using TicketBooking.Api.Admin.Classes;
using TicketBooking.Api.Admin.Models;

namespace AdminUnitTest
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            Movie moviemodel = new Movie();
            moviemodel.City = "test";
            moviemodel.Genre = "test";
            moviemodel.Language = "test";
            moviemodel.MovieDate = DateTime.Now;
            moviemodel.AvaliableTickets = 100;
            moviemodel.MovieName = "test";
            moviemodel.MultiplexName = "test";

            Addmovies movie = new Addmovies();

            string output = movie.addnewmovie(moviemodel);

            string expectedValue = "Movie Added Successfully";

            Assert.Equal(expectedValue, output);
        }
    }
}
